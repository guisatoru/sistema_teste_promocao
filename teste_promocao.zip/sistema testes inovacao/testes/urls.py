from django.urls import path
from . import views
from .views import LojaAutocomplete, SolicitanteAutocomplete, FuncaoAutocomplete

app_name = "testes"

urlpatterns = [
    path("", views.teste_list, name="lista"),
    path("novo/", views.teste_create, name="novo"),
    path("<int:pk>/pagar/", views.teste_pagar_premio, name="pagar"),
    path("<int:pk>/acao/<str:acao>/", views.teste_acao, name="acao"),  # promover/cancelar
    
    path('loja-autocomplete/', LojaAutocomplete.as_view(), name='loja-autocomplete'),
    path("solicitante-autocomplete/", SolicitanteAutocomplete.as_view(), name="solicitante-autocomplete"),
    path("funcao-autocomplete/", FuncaoAutocomplete.as_view(), name="funcao-autocomplete"),
]
