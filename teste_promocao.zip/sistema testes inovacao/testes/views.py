from django.contrib import messages
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST
from dal import autocomplete
from .forms import TestePromocaoForm
from .models import Funcao, PremioPago, Solicitante, TestePromocao, Loja

class LojaAutocomplete(autocomplete.Select2QuerySetView):
    def get_queryset(self):
        qs = Loja.objects.all()

        if self.q:
            qs = qs.filter(nome__icontains=self.q)

        return qs

class SolicitanteAutocomplete(autocomplete.Select2QuerySetView):
    def get_queryset(self):
        qs = Solicitante.objects.all()
        if self.q:
            qs = qs.filter(nome__icontains=self.q)
        return qs


class FuncaoAutocomplete(autocomplete.Select2QuerySetView):
    def get_queryset(self):
        qs = Funcao.objects.all()
        if self.q:
            qs = qs.filter(nome__icontains=self.q)
        return qs

def redirect_back_or_list(request, fallback_url_name="testes:lista"):
    """
    Volta para a página anterior (mantendo filtros da querystring),
    com fallback para a lista se não houver HTTP_REFERER.
    """
    ref = request.META.get("HTTP_REFERER")
    return redirect(ref) if ref else redirect(fallback_url_name)


def teste_list(request):
    q = (request.GET.get("q") or "").strip()
    re_ = (request.GET.get("re") or "").strip()
    solicitante_id = (request.GET.get("solicitante") or "").strip()
    status = (request.GET.get("status") or "").strip()

    testes = (
        TestePromocao.objects.select_related("loja", "loja__regiao", "solicitante")
        .prefetch_related("premios")
        .all()
    )

    if q:
        testes = testes.filter(colaborador_nome__icontains=q)

    if re_:
        testes = testes.filter(colaborador_re__icontains=re_)

    if solicitante_id:
        testes = testes.filter(solicitante_id=solicitante_id)

    if status:
        testes = testes.filter(status=status)

    # Ordenação: em andamento primeiro e mais recentes em cima
    testes = testes.order_by("status", "-data_inicio")

    solicitantes = Solicitante.objects.order_by("nome")

    context = {
        "testes": testes,
        "solicitantes": solicitantes,
        "filtros": {
            "q": q,
            "re": re_,
            "solicitante": solicitante_id,
            "status": status,
        },
    }
    return render(request, "testes/teste_list.html", context)


def teste_create(request):
    if request.method == "POST":
        form = TestePromocaoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Teste cadastrado com sucesso!")
            return redirect("testes:lista")
    else:
        form = TestePromocaoForm()

    return render(request, "testes/teste_form.html", {"form": form})


@require_POST
def teste_acao(request, pk, acao):
    teste = get_object_or_404(TestePromocao, pk=pk)

    # Bloqueio: se não estiver em andamento, não altera
    if teste.status != TestePromocao.Status.EM_ANDAMENTO:
        messages.error(request, "Este teste já está finalizado e não pode ser alterado.")
        return redirect_back_or_list(request)

    if acao == "promover":
        teste.status = TestePromocao.Status.PROMOVER
        teste.data_promovido = timezone.localdate()
        teste.data_cancelado = None
        teste.save(update_fields=["status", "data_promovido", "data_cancelado"])
        messages.success(request, "Teste marcado como PROMOVIDO.")
    elif acao == "cancelar":
        teste.status = TestePromocao.Status.CANCELAR
        teste.data_cancelado = timezone.localdate()
        teste.data_promovido = None
        teste.save(update_fields=["status", "data_cancelado"])
        messages.success(request, "Teste marcado como CANCELADO.")
    else:
        messages.error(request, "Ação inválida.")

    return redirect_back_or_list(request)


@require_POST
@transaction.atomic
def teste_pagar_premio(request, pk):
    teste = get_object_or_404(TestePromocao, pk=pk)

    # Bloqueio: se não estiver em andamento, não paga prêmio
    if teste.status != TestePromocao.Status.EM_ANDAMENTO:
        messages.error(
            request,
            "Este teste está finalizado (promovido/cancelado) e não pode receber prêmio.",
        )
        return redirect_back_or_list(request)

    existentes = set(teste.premios.values_list("numero_premio", flat=True))
    proximo = next((n for n in (1, 2, 3) if n not in existentes), None)

    if proximo is None:
        messages.error(request, "Este teste já tem 3 prêmios pagos (limite atingido).")
        return redirect_back_or_list(request)

    PremioPago.objects.create(
        teste=teste,
        numero_premio=proximo,
        data_pagamento=timezone.localdate(),
        observacao=(request.POST.get("observacao") or "").strip(),
    )

    messages.success(request, f"Prêmio {proximo} lançado com sucesso!")
    return redirect_back_or_list(request)
