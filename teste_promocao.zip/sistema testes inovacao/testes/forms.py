from django import forms
from .models import TestePromocao
from dal import autocomplete

class TestePromocaoForm(forms.ModelForm):
    class Meta:
        model = TestePromocao
        fields = [
            "colaborador_nome",
            "colaborador_re",
            "loja",
            "solicitante",
            "funcao",
            "data_inicio",
            "anexo_folha_teste",
            "observacoes",
        ]
        widgets = {
            "loja": autocomplete.ModelSelect2(
                url='testes:loja-autocomplete'
            ),
            "solicitante": autocomplete.ModelSelect2(url="testes:solicitante-autocomplete"),
            "funcao": autocomplete.ModelSelect2(url="testes:funcao-autocomplete"),
            
            "data_inicio": forms.DateInput(attrs={"type": "date"}),
            "observacoes": forms.Textarea(attrs={"rows": 3}),
        }
