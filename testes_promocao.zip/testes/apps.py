from django.apps import AppConfig


class TestesConfig(AppConfig):
    name = 'testes'
