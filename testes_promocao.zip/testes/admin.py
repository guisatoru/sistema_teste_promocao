from django.contrib import admin
from .models import Regiao, Loja, Solicitante, TestePromocao, PremioPago

@admin.register(Loja)
class LojaAdmin(admin.ModelAdmin):
    search_fields = ("nome",)
    list_display = ("nome", "regiao")
    list_filter = ("regiao",)

@admin.register(Regiao)
class RegiaoAdmin(admin.ModelAdmin):
    search_fields = ("nome",)

@admin.register(Solicitante)
class SolicitanteAdmin(admin.ModelAdmin):
    search_fields = ("nome",)

class PremioInline(admin.TabularInline):
    model = PremioPago
    extra = 0

@admin.register(TestePromocao)
class TestePromocaoAdmin(admin.ModelAdmin):
    autocomplete_fields = ("loja", "solicitante")  # <- aqui
    search_fields = ("colaborador_nome", "colaborador_re", "funcao_em_teste", "loja__nome")
    list_filter = ("status", "loja__regiao", "loja", "solicitante")
    inlines = [PremioInline]
