(function () {
  function confirmarAcao(mensagem) {
    return window.confirm(mensagem);
  }

  // debounce do filtro
  let filtroTimer = null;
  function autoFiltrar(form, delayMs) {
    clearTimeout(filtroTimer);
    filtroTimer = setTimeout(() => form.submit(), delayMs);
  }

  document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("filtroForm");
    if (!form) return;

    // auto-filtrar quando digitar
    form.querySelectorAll("[data-autofilter='input']").forEach((el) => {
      el.addEventListener("input", () => autoFiltrar(form, 500));
    });

    // auto-filtrar quando mudar select
    form.querySelectorAll("[data-autofilter='change']").forEach((el) => {
      el.addEventListener("change", () => autoFiltrar(form, 0));
    });

    // confirmações (qualquer botão/link com data-confirm)
    document.querySelectorAll("[data-confirm]").forEach((el) => {
      el.addEventListener("click", (e) => {
        const msg = el.getAttribute("data-confirm");
        if (!confirmarAcao(msg)) e.preventDefault();
      });
    });

    // confirmações para submits (form com data-confirm)
    document.querySelectorAll("form[data-confirm]").forEach((f) => {
      f.addEventListener("submit", (e) => {
        const msg = f.getAttribute("data-confirm");
        if (!confirmarAcao(msg)) e.preventDefault();
      });
    });
  });
})();

// Auto-submit com debounce
let filtroTimer = null;

function autoFiltrar(delayMs = 400) {
  clearTimeout(filtroTimer);
  filtroTimer = setTimeout(() => {
    const form = document.getElementById("filtroForm");
    if (form) form.submit();
  }, delayMs);
}

function confirmarAcao(msg) {
  return confirm(msg);
}

// Deixa funções acessíveis no HTML inline (oninput/onchange/onclick)
window.autoFiltrar = autoFiltrar;
window.confirmarAcao = confirmarAcao;
