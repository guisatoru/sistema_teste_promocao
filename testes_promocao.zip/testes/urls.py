from django.urls import path
from . import views

app_name = "testes"

urlpatterns = [
    path("", views.teste_list, name="lista"),
    path("novo/", views.teste_create, name="novo"),
    path("<int:pk>/pagar/", views.teste_pagar_premio, name="pagar"),
    path("<int:pk>/acao/<str:acao>/", views.teste_acao, name="acao"),  # promover/cancelar
]
