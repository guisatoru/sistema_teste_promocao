from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

class Regiao(models.Model):
    nome = models.CharField(max_length=80, unique=True)
    
    class Meta:
        verbose_name = "Região"
        verbose_name_plural = "Regiões"

    def __str__(self):
        return self.nome


class Loja(models.Model):
    nome = models.CharField(max_length=120, unique=True)
    regiao = models.ForeignKey(Regiao, on_delete=models.PROTECT)
    
    class Meta:
        verbose_name = "Loja"
        verbose_name_plural = "Lojas"

    def __str__(self):
        return self.nome


class Supervisor(models.Model):
    nome = models.CharField(max_length=120)

    class Meta:
        verbose_name = "Supervisor"
        verbose_name_plural = "Supervisores"

    def __str__(self):
        return self.nome


class TestePromocao(models.Model):
    class Status(models.TextChoices):
        EM_ANDAMENTO = "EM_ANDAMENTO", "Em andamento"
        PROMOVER = "PROMOVER", "Promover"
        CANCELAR = "CANCELAR", "Cancelar"
        FINALIZADO = "FINALIZADO", "Finalizado"
        
    class Meta:
        verbose_name = "Teste de promoção"
        verbose_name_plural = "Testes de promoção"

    # você digita manualmente
    colaborador_nome = models.CharField(max_length=120)
    colaborador_re = models.CharField(max_length=30)

    loja = models.ForeignKey(Loja, on_delete=models.PROTECT)
    supervisor = models.ForeignKey(Supervisor, on_delete=models.PROTECT)

    funcao_em_teste = models.CharField(max_length=120)  # simples e direto
    data_inicio = models.DateField()

    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.EM_ANDAMENTO
    )

    observacoes = models.TextField(blank=True)
    anexo_folha_teste = models.FileField(upload_to="folhas_teste/", blank=True, null=True)

    @property
    def regiao(self):
        return self.loja.regiao  # vem automaticamente

    @property
    def premios_pagos(self):
        return self.premios.count()

    def __str__(self):
        return f"{self.colaborador_nome} ({self.colaborador_re}) - {self.funcao_em_teste}"


class PremioPago(models.Model):
    teste = models.ForeignKey(TestePromocao, related_name="premios", on_delete=models.CASCADE)

    # isso garante: no máximo 3 por teste
    numero_premio = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(3)]
    )

    data_pagamento = models.DateField()
    observacao = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["numero_premio"]
        constraints = [
            models.UniqueConstraint(
                fields=["teste", "numero_premio"],
                name="uniq_numero_premio_por_teste",
            )
        ]

    def __str__(self):
        return f"{self.teste} - Prêmio {self.numero_premio}"
