from django import forms
from .models import TestePromocao

class TestePromocaoForm(forms.ModelForm):
    class Meta:
        model = TestePromocao
        fields = [
            "colaborador_nome",
            "colaborador_re",
            "loja",
            "supervisor",
            "funcao_em_teste",
            "data_inicio",
            "anexo_folha_teste",
            "observacoes",
        ]
        widgets = {
            "data_inicio": forms.DateInput(attrs={"type": "date"}),
            "observacoes": forms.Textarea(attrs={"rows": 3}),
        }
