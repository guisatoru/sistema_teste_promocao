from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.views.decorators.http import require_POST
from django.db import transaction
from django.db.models import Q

from .models import TestePromocao, PremioPago, Supervisor
from .forms import TestePromocaoForm


def teste_list(request):
    q = (request.GET.get("q") or "").strip()
    re_ = (request.GET.get("re") or "").strip()
    supervisor_id = (request.GET.get("supervisor") or "").strip()
    status = (request.GET.get("status") or "").strip()

    testes = (
        TestePromocao.objects
        .select_related("loja", "loja__regiao", "supervisor")
        .prefetch_related("premios")
    )

    if q:
        testes = testes.filter(colaborador_nome__icontains=q)

    if re_:
        testes = testes.filter(colaborador_re__icontains=re_)

    if supervisor_id:
        testes = testes.filter(supervisor_id=supervisor_id)

    if status:
        testes = testes.filter(status=status)

    # ordenação: em andamento primeiro e mais recentes em cima
    testes = testes.order_by("status", "-data_inicio")

    supervisores = Supervisor.objects.all().order_by("nome")

    context = {
        "testes": testes,
        "supervisores": supervisores,
        "filtros": {
            "q": q,
            "re": re_,
            "supervisor": supervisor_id,
            "status": status,
        }
    }
    return render(request, "testes/teste_list.html", context)


def teste_create(request):
    if request.method == "POST":
        form = TestePromocaoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Teste cadastrado com sucesso!")
            return redirect("testes:lista")
    else:
        form = TestePromocaoForm()

    return render(request, "testes/teste_form.html", {"form": form})


@require_POST
def teste_acao(request, pk, acao):
    teste = get_object_or_404(TestePromocao, pk=pk)

    # bloqueio: se não estiver em andamento, não altera
    if teste.status != TestePromocao.Status.EM_ANDAMENTO:
        messages.error(request, "Este teste já está finalizado e não pode ser alterado.")
        return redirect("testes:lista")

    if acao == "promover":
        teste.status = TestePromocao.Status.PROMOVER
        teste.save(update_fields=["status"])
        messages.success(request, "Teste marcado como PROMOVER.")
    elif acao == "cancelar":
        teste.status = TestePromocao.Status.CANCELAR
        teste.save(update_fields=["status"])
        messages.success(request, "Teste marcado como CANCELAR.")
    else:
        messages.error(request, "Ação inválida.")

    return redirect("testes:lista")


@require_POST
@transaction.atomic
def teste_pagar_premio(request, pk):
    teste = get_object_or_404(TestePromocao, pk=pk)

    # bloqueio: se não estiver em andamento, não paga prêmio
    if teste.status != TestePromocao.Status.EM_ANDAMENTO:
        messages.error(request, "Este teste está finalizado (promovido/cancelado) e não pode receber prêmio.")
        return redirect("testes:lista")

    existentes = set(teste.premios.values_list("numero_premio", flat=True))
    proximo = None
    for n in (1, 2, 3):
        if n not in existentes:
            proximo = n
            break

    if proximo is None:
        messages.error(request, "Este teste já tem 3 prêmios pagos (limite atingido).")
        return redirect("testes:lista")

    PremioPago.objects.create(
        teste=teste,
        numero_premio=proximo,
        data_pagamento=request.POST.get("data_pagamento") or teste.data_inicio,
        observacao=(request.POST.get("observacao") or "").strip(),
    )

    messages.success(request, f"Prêmio {proximo} lançado com sucesso!")
    return redirect("testes:lista")
